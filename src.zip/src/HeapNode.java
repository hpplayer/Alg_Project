
public class HeapNode {
	int name;
	int values;
	HeapNode parentNode;
}
