import java.util.ArrayList;


public class Node {
	int name;
	int BW;
	Node Dad;
	ArrayList<Edge> edges;
	int NumOfedges;
}
