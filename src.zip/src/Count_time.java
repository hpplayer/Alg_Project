import java.io.*;
import java.text.*;
import java.util.*;



public class Count_time {
	static List<Long> timeList;
	
	synchronized void count_time() {
		timeList = new ArrayList<Long>();
	
		for (int b3 = 0; b3 < 100; b3++){
			
		long startTime = System.nanoTime();
		for (int i =0; i < 100; i++){
		System.out.print("");}
		long endTime = System.nanoTime();
		long duration = (endTime - startTime);
		
		timeList.add(duration);
		//System.out.println("solution time: " + new DecimalFormat("#.#################").format(duration) + " Seconds");
		

		}//end 1st outer loop
		try{
		final OutputStream os = new FileOutputStream("/D:/test.txt");
		final PrintStream printStream = new PrintStream(os);
		
		for (int i2 = 0; i2 < timeList.size(); i2 ++){
			System.out.println("Your " + i2 + " read is: " + timeList.get(i2));		
			printStream.println(timeList.get(i2) + " \n");


		}
		printStream.close();	}catch(Exception o){}
		
	
		
	}
	public static void main(String[] args){
		new Count_time().count_time();
		
	}
}
