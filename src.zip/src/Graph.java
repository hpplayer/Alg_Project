/*
import java.io.FileNotFoundException;
import java.util.*;


public class Graph {
	private int node = 5000;
	private ArrayList<Edge>[] sparseG;

	//List<Integer> denseG;
	
	
	public void Sparse(){
		Edge e;
	
		int weight;
		sparseG = new ArrayList[5000];
		for (int i = 0; i < 5000; i++){
			sparseG[i] = new ArrayList<Edge>();
			for ( int j = 0; j < 6; j++){//for each node, generate 6 edges, if already have 6, exit.
			if (sparseG[i].size()>6)
				continue;
				//break;
			else{
				int w = this.randomGenerator();//generate node w
				if (w == i){
					
				}
				if ( w < i){
					if (findEdge(w, i) != null){
					weight = findEdge(i, w).weight();}
					else{
						weight = (int)(Math.random()*5000 +1 );}
				}else{
					weight = (int)(Math.random()*5000 + 1);
				}
			e = new Edge(i, w, weight);
			SparseAddEdge(e);
				}//end else
			}//end inner loop
		}//end outer loop
		

		
	}
	
	public Edge findEdge(int v, int w){
		Edge e = null;
		for (int i = 0; i < sparseG[v].size(); i++){
		if (sparseG[v].get(i).endPointW() == w){
				e= sparseG[v].get(i);
			}
		
		}
				return e;
	}
	
	public int randomGenerator(){
		int random = (int)(Math.random()*5000);
		return random;
	}
	
	public void SparseAddEdge(Edge e){
		int v = e.endPointV();
		int w = e.endPointW();
		sparseG[v].add(e);
	}
	
	  public String toString() {
		  String s ="";
		  String newLine = System.getProperty("line.separator");
		  for (int i = 0; i < 5000; i++){
			  for (int j = 0; j < 6; j++){
			  int v = sparseG[i].get(j).endPointV();
			  int w = sparseG[i].get(j).endPointW();
			  int weight = sparseG[i].get(j).weight();
			  s = s + " v: " + v + " w: " + w + " weight: " + weight + newLine;
			  } 
			
		  }
		  System.out.println(s);
		  return s;
	  }
	public static void main(String[] args) throws FileNotFoundException{
		Graph test = new Graph();
		test.Sparse();
		
		
		java.io.PrintStream ps = new java.io.PrintStream( "D:/Sparse_out.txt" );
		ps.print(test.toString());
		ps.flush();
		ps.close();
		
	
	}
}
*/

import java.io.FileNotFoundException;
import java.util.*;



public class Graph {
    private int node = 5000;
    public ArrayList<Edge>[] sparseG;
    public ArrayList<Edge>[] denseG;

    //List<Integer> denseG;
    public void Sparse() {
        sparseG = new ArrayList[5000];
        for (int i = 0; i < 5000; i++) {
            sparseG[i] = new ArrayList<Edge>();
            for (int j = 0; j < 6; j++){  // for each node, generate 6 edges, if already have 6, exit.
                int w = this.randomGenerator();  // generate node w
           
                int weight;
                if (w == i) {
                    j--;
                    continue;
                } else if (w < i) {
                    Edge edge = findEdge(w, i);
                    if (edge != null) {
                       weight = edge.weight();
                    } else{
                       weight = (int)(Math.random()*5000 +1 );
                    }
                } else{
                    weight = (int)(Math.random()*5000 + 1);
                }
       
                Edge e = new Edge(i, w, weight);
                SparseAddEdge(e);
            } //end inner loop
        } //end outer loop    
    }
    
    public void Dense() {
        denseG = new ArrayList[5000];
        for (int i = 0; i < 5000; i++) {
        	denseG[i] = new ArrayList<Edge>();
            for (int j = 0; j < 1000; j++){  // for each node, generate 1000 edges, if already have 6, exit.
                int w = this.randomGenerator();  // generate node w
           
                int weight;
                if (w == i) {
                    j--;
                    continue;
                } else if (w < i) {
                    Edge edge = findEdgeDense(w, i);
                    if (edge != null) {
                       weight = edge.weight();
                    } else{
                       weight = (int)(Math.random()*5000 +1 );
                    }
                } else{
                    weight = (int)(Math.random()*5000 + 1);
                }
       
                Edge e = new Edge(i, w, weight);
                DenseAddEdge(e);
            } //end inner loop
        } //end outer loop    
    }
    
    public Edge findEdge(int v, int w){
        Edge e = null;
        for (int i = 0; i < sparseG[v].size(); i++){
            if (sparseG[v].get(i).endPointW() == w){
                e= sparseG[v].get(i);
            }
        }
        return e;
    }
    
    public Edge findEdgeDense(int v, int w){
        Edge e = null;
        for (int i = 0; i < denseG[v].size(); i++){
            if (denseG[v].get(i).endPointW() == w){
                e= denseG[v].get(i);
            }
        }
        return e;
    }
    
    public int randomGenerator(){
        int random = (int)(Math.random()*5000);
        return random;
    }
    
    public void SparseAddEdge(Edge e){
        int v = e.endPointV();
        int w = e.endPointW();
        sparseG[v].add(e);
    }
    
    public void DenseAddEdge(Edge e){
        int v = e.endPointV();
        int w = e.endPointW();
        denseG[v].add(e);
    }
    
      public String toString() {
          String s ="[ ";
          String newLine = System.getProperty("line.separator");
          for (int i = 0; i < 5000; i++){
              for (int j = 0; j < 6; j++){
              int v = sparseG[i].get(j).endPointV();
              int w = sparseG[i].get(j).endPointW();
              int weight = sparseG[i].get(j).weight();
              s += " v: " + v + " w: " + w + " weight: " + weight + newLine;
              }
          }
        //  System.out.print(s);
          return s;
      }
      
      public String toStringDense() {
          String s ="[ ";
          String newLine = System.getProperty("line.separator");
          for (int i = 0; i < 5000; i++){
              for (int j = 0; j < 1000; j++){
              int v = denseG[i].get(j).endPointV();
              int w = denseG[i].get(j).endPointW();
              int weight = denseG[i].get(j).weight();
              s += " v: " + v + " w: " + w + " weight: " + weight + newLine;
              }
          }
         // System.out.print(s);
          return s;
      }

    public static void main(String[] args) throws FileNotFoundException{
        Graph test = new Graph();

        
        long startTime = System.nanoTime();
        test.Sparse();
       // java.io.PrintStream ps = new java.io.PrintStream( "C:/out.txt" );
       // ps.print(test.toString());
       // ps.flush();
       // ps.close();
    	long endTime = System.nanoTime();
		long duration = (endTime - startTime);
		System.out.println("Creation of sparse graph costs: " + duration/1000000000.0 + " seconds");
        
		
	    long startTime2 = System.nanoTime();
       // java.io.PrintStream ps2 = new java.io.PrintStream( "C:/out2.txt" );  
        test.Dense();
      //  ps2.print(test.toStringDense());
       // ps2.flush();
       // ps2.close();
    	long endTime2 = System.nanoTime();
		long duration2 = (endTime2 - startTime2);
		System.out.println("Creation of dense graph costs: " + duration2/1000000000.0 + " seconds");
        
    
    }
}