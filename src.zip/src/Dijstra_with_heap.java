import java.util.ArrayList;


public class Dijstra_with_heap {
	private int BW = 0;
	int sourceNumber = 4999; //range 0 to 5000
	int DestiNumber = 0;//range 0 to 5000
	Heap heap;
	Node[] nodelist;
	
	public void initializaiton(String a){
		nodelist = new Node[5000];
		heap = new Heap(); 
		
		if (a.equals("sparse") ){
		Graph sparse = new Graph();
		sparse.Sparse();
		for (int i = 0; i < 5000; i ++){
			nodelist[i]  = new Node();
			nodelist[i].name = i;
			nodelist[i].Dad = null;
			nodelist[i].BW = -1;//-1 means the node is unseen since we dont have negative bandwidth
			nodelist[i].edges =  sparse.sparseG[i];	
			nodelist[i].NumOfedges = 6;
		}
		
	
		}//end if 
		
		if (a.equals("dense") ){
			Graph dense = new Graph();
			dense.Dense();
			for (int i = 0; i < 5000; i ++){
				nodelist[i]  = new Node();
				nodelist[i].name = i;
				nodelist[i].Dad = null;
				nodelist[i].BW = -1;//-1 means the node is unseen since we dont have negative bandwidth
				nodelist[i].edges =  dense.denseG[i];		
				nodelist[i].NumOfedges = 1000;
			}
			
		
			}//end if 
			
		
		nodelist[sourceNumber].BW = 0;//the bandwidth of path from s to s is 0
		System.out.println("Initialization done!");
	}
	
	public void NEWdijstra(){
		int nodeNum;
		Edge temp;
		Node sourceNode = nodelist[sourceNumber];
			for (int i = 0; i < sourceNode.NumOfedges; i++){
				temp = sourceNode.edges.get(i);
				nodeNum = temp.endPointW();
				nodelist[nodeNum].Dad = sourceNode;
				nodelist[nodeNum].BW = temp.weight();
				//heap.insert(nodelist[nodeNum].BW);//create a heap contains value of vertex
				heap.insertBW(nodeNum, nodelist[nodeNum].BW);//store i value and BW value
			}
			
			System.out.println("Operations done on soruce node and its fringe!");
			
			while(heap.size() != 0){
			//find value of max fringe and remove it;
				int valueOfh_i = (Integer) heap.max();
				//System.out.println(MaxFringeValue);
				//System.out.println("Size " + heap.size());
				//heap.toString();
			//	System.out.println(heap.Find(MaxFringeValue));
				//System.out.println(valueOfh_i);
				Node Maxfringe = nodelist[valueOfh_i];
				heap.removeMax();
				//System.out.println("Done on removing min value");
				for ( int j = 0; j <Maxfringe.NumOfedges; j++){
					int tempNodeNum = Maxfringe.edges.get(j).endPointW();
						if (nodelist[tempNodeNum].BW == -1){//when node is unseen
							//System.out.println("last run is case 1");
							nodelist[tempNodeNum].Dad = Maxfringe;
							nodelist[tempNodeNum].BW = returnMin(Maxfringe.BW, Maxfringe.edges.get(j).weight());
							//heap.insert(nodelist[tempNodeNum].BW);
						//	System.out.println("BW: " + nodelist[tempNodeNum].BW + " name " + tempNodeNum);
							//System.out.println("inserting node: " + tempNodeNum + " BW: " + nodelist[tempNodeNum].BW);
							heap.insertBW(tempNodeNum, nodelist[tempNodeNum].BW);
							//System.out.println(nodelist[tempNodeNum].BW);
							//heap.toString();
						}//end case1 if
						else if (heap.contains(tempNodeNum) && nodelist[tempNodeNum].BW < returnMin(Maxfringe.BW, Maxfringe.edges.get(j).weight())){
							//when node is in fringe and needs updates
							//System.out.println("GOT PROBLEM IN CASE 2");
							// System.out.println("last run is case 2");
							 nodelist[tempNodeNum].Dad = Maxfringe;
							 nodelist[tempNodeNum].BW = returnMin(Maxfringe.BW, Maxfringe.edges.get(j).weight());
							 //System.out.println("BW: " + nodelist[tempNodeNum].BW + " name " + tempNodeNum);
							 heap.update(tempNodeNum, nodelist[tempNodeNum].BW);
							
						}//end case2 if 
				}//end for loop
				//break while loop when t is removed from fringelist
			
				//if (nodelist[DestiNumber].BW != -1 && !heap.contains(DestiNumber)){
					if ((int)heap.D.get(DestiNumber) != -1 && !heap.contains(DestiNumber)){
					break; 
				}
			
		}//end while loop
			System.out.println("Done Dijstra algorithm on the calculation from source node " + 500 + " to destination node " + DestiNumber + " !");
			}
			


public int returnMin(int a, int b){
	if (compare(a, b) <= 0)
		return a;
	else 
		return b;
}

public int compare(Object x, Object y){
	return ((Integer) x).compareTo((Integer) y);
}

public int calpath(){
	int totallength = 0;
	int numofnodes = 0;
	Node temp = nodelist[DestiNumber];
	while(temp.name != sourceNumber){
		totallength = totallength + temp.BW;
		temp = temp.Dad;	
		numofnodes++;
	}
	System.out.println("Done on calculating the length of path!");
	System.out.println("The Bandwidth is " + totallength + ", through " + numofnodes + " nodes" );
	return totallength;
}
	
	public static void main(String[] args){
		Dijstra_with_heap test = new Dijstra_with_heap();
		test.initializaiton("sparse");
		System.out.println("Start counting time...");
		
		 	long startTime = System.nanoTime();
			test.NEWdijstra();
			test.calpath();
			long endTime = System.nanoTime();
			long duration = (endTime - startTime);
			System.out.println("Dijstra algorithm on sparse graph with heap costs: " + duration/1000000000.0 + " seconds");
			
			
			System.out.println("----------------------------------------End sparse graph, Begin dense graph----------------------------");
			test.initializaiton("dense");
				System.out.println("Start counting time...");
			    long startTime2 = System.nanoTime();
				test.NEWdijstra();
				test.calpath();
				long endTime2 = System.nanoTime();
				long duration2 = (endTime2 - startTime2);
				System.out.println("Dijstra algorithm on dense graph with heap costs: " + duration2/1000000000.0 + " seconds");
	}
	
}
